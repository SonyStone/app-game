import {
  add,
  cross,
  dot,
  normalize,
  presetOrientation,
  referenceAxes,
  rotateOrientation,
  scale,
  toWorld,
  type Vec3,
  type ViewOrientation,
  type ViewReferenceFrame
} from './orientation'

/** Face-local U/V are the sole source for the rendered plane and all its hit targets. */
export const faces = [
  face('top', [1, 0, 0], [0, 1, 0]),
  face('bottom', [-1, 0, 0], [0, 1, 0]),
  face('front', [1, 0, 0], [0, 0, 1]),
  face('back', [1, 0, 0], [0, 0, -1]),
  face('right', [0, 0, -1], [0, 1, 0]),
  face('left', [0, 0, 1], [0, 1, 0])
]

/** Shared canonical targets: six faces, twelve edges and eight corners. */
export const targets = [
  ...new Map(faces.flatMap((f) => f.zones).map((zone) => [zone.id, zone])).values()
]

export function cubeMatrix(orientation: ViewOrientation, frame?: ViewReferenceFrame) {
  const right = cross(orientation.up, orientation.direction)
  const { x, y, z } = referenceAxes(frame)
  return matrix(
    [x, y, z]
      .flatMap((axis) => [
        dot(right, axis),
        -dot(orientation.up, axis),
        dot(orientation.direction, axis),
        0
      ])
      .concat([0, 0, 0, 1])
  )
}

export function faceVisible(
  face: (typeof faces)[number],
  orientation: ViewOrientation,
  frame?: ViewReferenceFrame
) {
  return dot(toWorld(face.normal, frame), orientation.direction) > 0.001
}

export function alignedFace(orientation: ViewOrientation, frame?: ViewReferenceFrame) {
  return faces.find(
    (face) => dot(toWorld(face.normal, frame), orientation.direction) > Math.cos(Math.PI / 180)
  )
}

/** Snap direction within eight degrees while transporting up without a roll discontinuity. */
export function snapOrientation(
  orientation: ViewOrientation,
  frame?: ViewReferenceFrame
): ViewOrientation | undefined {
  const nearest = targets
    .map((target) => presetOrientation(target.direction, frame))
    .sort(
      (a, b) => dot(b.direction, orientation.direction) - dot(a.direction, orientation.direction)
    )[0]!
  const cosine = dot(orientation.direction, nearest.direction)
  if (cosine < Math.cos((8 * Math.PI) / 180) || cosine > 1 - 1e-10) return
  return rotateOrientation(
    orientation,
    normalize(cross(orientation.direction, nearest.direction)),
    Math.acos(Math.min(1, cosine))
  )
}

function face(key: 'top' | 'bottom' | 'front' | 'back' | 'right' | 'left', u: Vec3, v: Vec3) {
  const normal = cross(u, v)
  const zones = [-1, 0, 1].flatMap((row) =>
    [-1, 0, 1].map((col) => {
      const direction = add(normal, add(scale(u, col), scale(v, row)))
      return { id: direction.join(','), direction, label: label(direction) }
    })
  )
  return {
    key,
    normal,
    u,
    v,
    zones,
    label: label(normal),
    transform: `${matrix([...u, 0, ...v, 0, ...normal, 0, 0, 0, 0, 1])} translateZ(var(--view-cube-half))`
  }
}

function label([x, y, z]: Vec3) {
  return [
    z > 0 ? 'Top' : z < 0 ? 'Bottom' : '',
    y < 0 ? 'Front' : y > 0 ? 'Back' : '',
    x > 0 ? 'Right' : x < 0 ? 'Left' : ''
  ]
    .filter(Boolean)
    .join(' ')
}

function matrix(values: number[]) {
  return `matrix3d(${values.map((value) => Number(value.toFixed(8))).join(',')})`
}
